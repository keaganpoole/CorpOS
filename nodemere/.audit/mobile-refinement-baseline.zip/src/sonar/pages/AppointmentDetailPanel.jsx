import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, Check, ChevronDown, Save, Trash2, X } from 'lucide-react';
import {
  TABLE_COLUMNS,
  formatDate,
  formatTime,
  formatTimestamp,
  formatTimestampFull,
  getFieldDef,
  normalizeOptionValue,
} from '../lib/appointmentSchema';
import { DEFAULT_FIELD_CONFIG } from '../lib/appointmentFieldConfig';

const getOptionValue = (option) => normalizeOptionValue(typeof option === 'string' ? option : option?.value);
const getConfiguredOptions = (field, fieldConfig) => fieldConfig?.[field.key]?.options || field.options || [];

const colorStyles = {
  emerald: { dot: '#10b981', className: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  cyan: { dot: 'var(--brandGradientStart)', className: 'bg-white/[0.04] text-zinc-300 border-white/[0.08]' },
  blue: { dot: 'var(--brandGradientEnd)', className: 'bg-white/[0.04] text-zinc-300 border-white/[0.08]' },
  amber: { dot: '#f59e0b', className: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  orange: { dot: '#f97316', className: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  fuchsia: { dot: '#d946ef', className: 'bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20' },
  rose: { dot: '#f43f5e', className: 'bg-rose-500/10 text-rose-400 border-rose-500/20' },
  indigo: { dot: '#6366f1', className: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' },
  zinc: { dot: '#71717a', className: 'bg-white/5 text-zinc-500 border-white/10' },
};

const getOptionColor = (field, fieldConfig, value) => {
  const normal = normalizeOptionValue(value);
  return fieldConfig?.[field.key]?.optionColors?.[normal]
    || fieldConfig?.[field.key]?.optionColors?.[value]
    || (typeof field.options?.find === 'function'
      ? field.options.find((option) => getOptionValue(option) === normal)?.color
      : null);
};

const SelectEditor = ({ field, value, onChange, fieldConfig }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = normalizeOptionValue(value);
  const options = getConfiguredOptions(field, fieldConfig).map(getOptionValue).filter(Boolean);

  useEffect(() => {
    if (!open) return undefined;
    const close = (event) => {
      if (!ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  const styleFor = (option) => {
    const color = getOptionColor(field, fieldConfig, option);
    if (color?.startsWith?.('#')) return { dot: color, className: 'bg-white/[0.04] text-white border-white/[0.08]' };
    return colorStyles[color] || colorStyles.zinc;
  };
  const currentStyle = current ? styleFor(current) : { dot: 'transparent', className: 'bg-white/[0.025] text-zinc-600 border-white/[0.05]' };

  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((next) => !next)} className={`flex min-h-[34px] w-full items-center justify-between gap-2 rounded-lg border px-2.5 py-1.5 text-left text-[11px] font-semibold tracking-[-0.02em] transition ${currentStyle.className}`}>
        <span className="flex min-w-0 items-center gap-2">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: currentStyle.dot }} />
          <span className={current ? 'truncate' : 'text-zinc-700'}>{current || 'Empty'}</span>
        </span>
        <ChevronDown size={12} className="shrink-0 text-zinc-600" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.98 }}
            className="absolute left-0 top-full z-50 mt-1.5 max-h-56 min-w-full overflow-y-auto rounded-xl border border-white/[0.08] bg-[#0a0a0a] py-1 shadow-[0_16px_48px_rgba(0,0,0,0.75)]"
          >
            <button type="button" onClick={() => { onChange(null); setOpen(false); }} className="flex w-full items-center gap-2 px-3 py-2 text-left text-[11px] font-semibold tracking-[-0.02em] text-zinc-500 hover:bg-white/[0.06]">
              <span className="h-2 w-2 rounded-full bg-zinc-700" />
              Empty
            </button>
            {options.map((option) => {
              const optionStyle = styleFor(option);
              const active = current === option;
              return (
                <button key={option} type="button" onClick={() => { onChange(option); setOpen(false); }} className={`flex w-full items-center gap-2 px-3 py-2 text-left text-[11px] font-semibold tracking-[-0.02em] hover:bg-white/[0.06] ${active ? 'text-white' : 'text-zinc-400'}`}>
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: optionStyle.dot }} />
                  <span className="min-w-0 flex-1 truncate">{option}</span>
                  {active && <Check size={11} className="brand-icon" />}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const LookupEditor = ({ value, options = [], onChange, placeholder = 'Search...' }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef(null);
  const current = options.find((option) => String(option.value) === String(value)) || null;
  const filtered = options.filter((option) => option.label.toLowerCase().includes(query.toLowerCase()));

  useEffect(() => {
    if (!open) return undefined;
    const close = (event) => {
      if (!ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((next) => !next)} className="flex min-h-[34px] w-full items-center justify-between gap-2 rounded-lg border border-white/[0.06] bg-white/[0.025] px-2.5 py-1.5 text-left text-[11px] font-semibold tracking-[-0.02em] text-zinc-300 transition hover:border-white/15">
        <span className={`truncate ${current ? 'text-white' : 'text-zinc-700'}`}>{current?.label || 'Empty'}</span>
        <ChevronDown size={12} className="shrink-0 text-zinc-600" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.98 }}
            className="absolute left-0 top-full z-50 mt-1.5 min-w-full overflow-hidden rounded-xl border border-white/[0.08] bg-[#0a0a0a] shadow-[0_16px_48px_rgba(0,0,0,0.75)]"
          >
            <div className="border-b border-white/[0.04] p-2.5">
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={placeholder}
                className="w-full rounded-lg border border-white/[0.06] bg-[#0a0a0a] px-2.5 py-2 text-[11px] text-white outline-none placeholder:text-zinc-700 focus:!border-white/[0.06] focus:!outline-none"
              />
            </div>
            <div className="max-h-56 overflow-y-auto py-1">
              <button type="button" onClick={() => { onChange(null); setOpen(false); }} className="flex w-full items-center px-3 py-2 text-left text-[11px] font-semibold tracking-[-0.02em] text-zinc-500 hover:bg-white/[0.06]">
                Empty
              </button>
              {filtered.map((option) => (
                <button key={option.value} type="button" onClick={() => { onChange(option.value); setOpen(false); }} className={`flex w-full items-center gap-2 px-3 py-2 text-left text-[11px] font-semibold tracking-[-0.02em] hover:bg-white/[0.06] ${current?.value === option.value ? 'text-white' : 'text-zinc-400'}`}>
                  <span className="min-w-0 flex-1 truncate">{option.label}</span>
                  {current?.value === option.value && <Check size={11} className="brand-icon" />}
                </button>
              ))}
              {filtered.length === 0 && <div className="px-3 py-2 text-[11px] text-zinc-600">No matches</div>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const DateEditor = ({ value, onChange, type = 'date' }) => {
  const ref = useRef(null);
  const [draft, setDraft] = useState('');
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    if (!editing) return undefined;
    const frame = requestAnimationFrame(() => {
      ref.current?.focus();
      ref.current?.showPicker?.();
    });
    return () => cancelAnimationFrame(frame);
  }, [editing]);

  const display = type === 'date'
    ? (value ? formatDate(value) : '')
    : (value ? formatTime(value) : '');

  const open = () => {
    setDraft(value || '');
    setEditing(true);
  };

  const save = () => {
    setEditing(false);
    onChange(draft || null);
  };

  return (
    <div className="relative">
      <button type="button" onClick={open} className="w-full rounded-lg border border-white/[0.06] bg-white/[0.025] px-2.5 py-2 text-left text-[12px] text-zinc-400 transition hover:text-white">
        {display || <span className="text-zinc-700">Empty</span>}
      </button>
      {editing && (
        <input
          ref={ref}
          type={type}
          value={draft || ''}
          onChange={(event) => setDraft(event.target.value)}
          onBlur={save}
          onKeyDown={(event) => { if (event.key === 'Escape') setEditing(false); }}
          className="absolute left-0 top-full h-px w-px opacity-0 pointer-events-none [color-scheme:dark]"
          tabIndex={-1}
          aria-hidden="true"
        />
      )}
    </div>
  );
};

const buildPanelFields = (tableSchema) => {
  const columns = tableSchema?.columns || [
    { id: 'person_id', label: 'Customer / Person' },
    ...TABLE_COLUMNS.filter((field) => field.key !== 'person_id').map((field) => ({ id: field.key, label: field.label })),
  ];
  const fieldConfig = tableSchema?.fieldConfig || DEFAULT_FIELD_CONFIG;

  return columns
    .filter((column) => column.id !== 'select' && column.id !== 'avatar')
    .map((column) => {
      const baseField = getFieldDef(column.id);
      if (!baseField) return null;
      const config = fieldConfig[column.id] || {};
      return {
        ...baseField,
        key: column.id,
        label: baseField.label || column.label,
        options: config.options || baseField.options || [],
        optionColors: config.optionColors || {},
        editable: baseField.editable !== false,
      };
    })
    .filter(Boolean);
};

const FieldEditor = ({ field, value, onChange, errors, fieldConfig, lookupOptions }) => {
  const error = errors?.[field.key];
  const baseClass = `w-full rounded-lg border bg-white/[0.025] px-2.5 py-2 text-[12px] text-zinc-300 outline-none transition placeholder:text-zinc-700 focus:!outline-none ${error ? 'border-rose-500/40' : 'border-white/[0.06] focus:border-cyan-500/30'}`;

  if (!field.editable) {
    let display = value || '';
    if (field.type === 'timestamp') display = formatTimestampFull(value);
    if (field.type === 'date') display = formatDate(value);
    if (field.type === 'time' || field.type === 'computed_time') display = formatTime(value);
    return <div className="rounded-lg border border-white/[0.04] bg-white/[0.018] px-2.5 py-2 text-[12px] text-zinc-500">{display || 'Empty'}</div>;
  }

  if (field.type === 'select') return <SelectEditor field={field} value={value} onChange={onChange} fieldConfig={fieldConfig} />;
  if (field.type === 'person_lookup' || field.type === 'service_lookup' || field.type === 'receptionist_lookup') {
    return <LookupEditor value={value} options={lookupOptions[field.key] || []} onChange={onChange} placeholder={`Search ${field.label.toLowerCase()}...`} />;
  }
  if (field.type === 'number') {
    return <input value={value ?? ''} inputMode="numeric" onChange={(event) => {
      const raw = event.target.value.replace(/[^0-9]/g, '');
      const parsed = raw === '' ? null : parseInt(raw, 10);
      onChange(parsed == null ? null : Math.min(Math.max(parsed, field.min ?? 0), field.max ?? 999999));
    }} className={`${baseClass} tabular-nums`} />;
  }
  if (field.type === 'date') return <DateEditor value={value} onChange={onChange} type="date" />;
  if (field.type === 'time') return <DateEditor value={value} onChange={onChange} type="time" />;
  if (field.type === 'textarea') return <textarea value={value || ''} onChange={(event) => onChange(event.target.value || null)} rows={4} className={`${baseClass} resize-none leading-relaxed`} />;
  if (field.type === 'timestamp') return <DateEditor value={value} onChange={onChange} type="datetime-local" />;
  return (
    <input
      type="text"
      value={value || ''}
      onChange={(event) => onChange(event.target.value || null)}
      placeholder={field.label}
      className={baseClass}
    />
  );
};

const AppointmentDetailPanel = ({ appointment, onSave, onDelete, onClose, isNew = false, tableSchema = null, people = [], services = [], receptionists = [] }) => {
  const [edits, setEdits] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});
  const [saveSuccess, setSaveSuccess] = useState(false);

  const fields = useMemo(() => buildPanelFields(tableSchema), [tableSchema]);
  const fieldConfig = tableSchema?.fieldConfig || DEFAULT_FIELD_CONFIG;

  const lookupOptions = useMemo(() => ({
    person_id: people.map((person) => ({
      value: String(person.id),
      label: [person.first_name, person.last_name].filter(Boolean).join(' ').trim() || person.phone || person.email || 'Untitled Person',
      person,
    })),
    service_id: services.map((service) => ({ value: String(service.id), label: service.name || 'Untitled Service', service })),
    receptionist_id: receptionists.map((receptionist) => ({
      value: String(receptionist.id),
      label: receptionist.full_name || receptionist.first_name || `Receptionist ${receptionist.id}`,
      receptionist,
    })),
  }), [people, receptionists, services]);

  useEffect(() => {
    setEdits({});
    setErrors({});
    setSaveSuccess(false);
  }, [appointment?.id, isNew]);

  const currentAppointment = useMemo(() => {
    const base = isNew ? {} : (appointment || {});
    const merged = { ...base, ...edits };
    return merged;
  }, [appointment, edits, isNew]);

  if (!appointment && !isNew) return null;

  const displayName = currentAppointment._personName || 'Untitled Appointment';
  const contactLine = [formatDate(currentAppointment.date), formatTime(currentAppointment.time)].filter(Boolean).join(' at ') || 'No schedule yet';
  const hasChanges = Object.keys(edits).length > 0;

  const handleChange = (field, value) => {
    setEdits((prev) => {
      const next = { ...prev, [field.key]: value };
      return next;
    });
    if (errors[field.key]) setErrors((prev) => { const next = { ...prev }; delete next[field.key]; return next; });
    setSaveSuccess(false);
  };

  const validate = () => {
    const errs = {};
    if (!currentAppointment.date) errs.date = 'Date is required';
    if (!currentAppointment.time) errs.time = 'Start time is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await onSave(edits);
      setEdits({});
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 1800);
    } catch (err) {
      setErrors({ _general: err.message });
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await onDelete();
    } catch (err) {
      setErrors({ _general: err.message });
      setDeleting(false);
    }
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[50] bg-black/60" onClick={onClose} />
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        className="fixed bottom-0 right-0 top-0 z-[60] flex w-full max-w-[500px] flex-col overflow-hidden border-l border-white/[0.06] bg-[#0a0a0a] shadow-[0_0_80px_rgba(0,0,0,0.8)]"
      >
        <div className="shrink-0 border-b border-white/[0.04] px-7 py-6">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="mb-2 text-[11px] font-semibold tracking-[-0.02em] text-zinc-600">{isNew ? 'New Appointment' : 'Appointment'}</p>
              <h3 className="truncate text-2xl font-semibold tracking-[-0.04em] text-white">{displayName}</h3>
              <p className="mt-1 truncate text-[12px] text-zinc-500">{contactLine}</p>
            </div>
            <button onClick={onClose} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/[0.04] text-zinc-500 transition hover:bg-white/[0.08] hover:text-white">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="shrink-0 border-b border-white/[0.04] px-7 py-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={saving || (!hasChanges && !isNew)}
              className={`flex-1 rounded-xl px-4 py-2.5 text-[11px] font-semibold tracking-[-0.02em] transition active:scale-[0.98] disabled:opacity-30 ${saveSuccess ? 'border border-emerald-500/30 bg-emerald-500/20 text-emerald-400' : 'bg-white text-black hover:bg-cyan-400'}`}
            >
              {saveSuccess ? 'Saved' : saving ? 'Saving...' : <span className="inline-flex items-center justify-center gap-2"><Save size={12} /> Save</span>}
            </button>
            {!isNew && (
              <button onClick={handleDelete} disabled={deleting} className="rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-2.5 text-zinc-500 transition hover:border-rose-500/20 hover:bg-rose-500/10 hover:text-rose-400">
                <Trash2 size={12} />
              </button>
            )}
          </div>
        </div>

        {errors._general && (
          <div className="mx-7 mt-3 flex items-center gap-2 rounded-xl border border-rose-500/20 bg-rose-500/10 px-3 py-2">
            <AlertCircle size={12} className="shrink-0 text-rose-400" />
            <span className="text-[10px] text-rose-400">{errors._general}</span>
          </div>
        )}

        <div className="custom-scrollbar flex-1 overflow-y-auto px-7 py-5">
          <div className="space-y-4">
            {fields.map((field) => {
              const value = currentAppointment[field.key];
              return (
                <div key={field.key} className="space-y-2">
                  <label className="flex items-center justify-between gap-3">
                    <span className="min-w-0 truncate text-[11px] font-semibold tracking-[-0.02em] text-zinc-600">{field.label}</span>
                  </label>
                  <FieldEditor
                    field={field}
                    value={value}
                    onChange={(nextValue) => handleChange(field, nextValue)}
                    errors={errors}
                    fieldConfig={fieldConfig}
                    lookupOptions={lookupOptions}
                  />
                  {errors[field.key] && <p className="mt-1 text-[9px] text-rose-400">{errors[field.key]}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default AppointmentDetailPanel;
